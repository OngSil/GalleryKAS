package kas.member.model;

public class MemberSet {
	public static final int NO_ID = 1;
	public static final int NO_PWD = 2;
	public static final int PASS = 3;
	public static final int SIGN_UP_OK = 4;
	public static final int DUPLICATION = 5;
	public static final int SIGN_UP_FAIL = 6;
}
