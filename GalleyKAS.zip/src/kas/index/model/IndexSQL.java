package kas.index.model;

public class IndexSQL {
	static final String GETCONTENT = "select * from EXHIBITION order by CODE";
	   static final String GETKAS = "select * from EXHIBITION where artist='Jihee' or artist='JH' or artist='얀_하빅스_스텐'";
}
